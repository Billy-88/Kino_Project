# KINOproject
An odd - even game.

This project was developed during August 2020 as a summer vacation project for 
CB11 Coding Bootcamp, C# Stream – PeopleCert Education.
